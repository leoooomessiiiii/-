# Machine Learning with Titanic Data

## Directions to Run Pipeline

1. git clone https://github.com/ritvikmath/Machine-Learning-With-Titanic-Data.git

2. create two empty folders in the working directory called "model_plots" and "model_outputs"

3. run the pipeline with "python Titanic.py"

4. use the command "python Titanic.py clean" to restore to initial state (note: will remove all generated files)


